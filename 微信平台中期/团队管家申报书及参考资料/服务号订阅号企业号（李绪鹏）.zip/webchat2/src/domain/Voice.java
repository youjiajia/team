package domain;
/**
 * 
 * 语音model
 * @author 李绪鹏
 * @date 2014-10-25
 *
 */

public class Voice {
	// 语音文件id，可以调用上传媒体文件接口获取 
	private String mediaId;

	public String getMediaId() {
		return mediaId;
	}

	public void setMediaId(String mediaId) {
		this.mediaId = mediaId;
	}
	

}
