package domain.resp;

import domain.Basemessage;

/**
 * 消息基类（公众帐号 -> 企业用户）
 * 
 * @author 李绪鹏
 * @date 2014-10-25
 */
public abstract class Resp_BaseMessage extends Basemessage{
	/*// 位0x0001被标志时，星标刚收到的消息
	private int FuncFlag;*/
}
