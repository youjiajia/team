package domain;

/**
 * 
 * 图片model
 * 
 * @author 李绪鹏
 * @date 2014-10-25
 * 
 */
public class Image {
	private String mediaId;

	public String getMediaId() {
		return mediaId;
	}

	public void setMediaId(String mediaId) {
		this.mediaId = mediaId;
	}

}
