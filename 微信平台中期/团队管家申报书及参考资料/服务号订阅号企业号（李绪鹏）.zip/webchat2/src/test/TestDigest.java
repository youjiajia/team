package test;

import org.liufeng.course.util.SignUtil;

public class TestDigest {
	public void testDigest()
	{
	String string="aaaaaaaaa";
	
		
	}

}
