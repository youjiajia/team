package domain.resp;
import domain.Music;;

/**
 * 音乐消息
 * 
 * @author liufeng
 * @date 2013-05-19
 */
public class Resp_MusicMessage extends Resp_BaseMessage {
	// 音乐
	private Music Music;

	public Resp_MusicMessage() {
		super();
		this.setMsgType(RESP_MESSAGE_TYPE_MUSIC);
	}

	public Music getMusic() {
		return Music;
	}

	public void setMusic(Music music) {
		Music = music;
	}
}