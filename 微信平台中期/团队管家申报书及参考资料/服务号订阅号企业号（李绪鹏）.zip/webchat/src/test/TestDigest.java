package test;

import org.junit.Test;
import org.liufeng.course.util.MySignUtil;
import org.liufeng.course.util.SignUtil;

public class TestDigest {
	@Test
	public void testDigest()
	{
	String string="aaaaaaaaa";
	System.out.println(MySignUtil.wxcpt);
		
	}
	

}
