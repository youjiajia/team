package org.liufeng.weixin.pojo;

/**
 * 菜单
 * 
 * @author liufeng
 * @date 2013-08-08
 */
public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}